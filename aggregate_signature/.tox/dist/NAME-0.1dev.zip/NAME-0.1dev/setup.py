from distutils.core import setup

setup(
    name='NAME',
    version='0.1dev',
    packages=[],
    license='Creative Commons Attribution-Noncommercial-Share Alike license',
)